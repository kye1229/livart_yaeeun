## nav 16
font-weight:500; line-height: 1.2; letter-spacing:-0.02em;
## 로그인 14
font-size:0.88rem; line-height:1.2; letter-spacing:-0.02em;
## 메인배너 40
font-size:2.5rem; font-weight:600; letter-spacing:-0.02em;
## 메인배너 32
font-size:2.0rem; font-weight:600; letter-spacing:-0.02em;
## h3
font-size:2.0rem; font-weight:700; line-height:1.2; letter-spacing:-0.02em;
## best a
font-size: 1.25rem; font-weight:500; line-height:1.2; letter-spacing:-0.02em;
## 더보기
font-size:1.25rem; font-weight:700; letter-spacing:-0.02em;
## price
font-size:1.25rem; font-weight:600; letter-spacing:-0.02em;